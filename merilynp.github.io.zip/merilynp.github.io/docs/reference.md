# Documentación de Funciones

Función Euler

::: ode.euler


método de Runge-kutta de segundo orden

::: ode.rk2


método de Runge-kutta de cuarto orden

::: ode.rk4
